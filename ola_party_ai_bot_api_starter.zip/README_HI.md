# Ola Party AI Bot API — Starter Project

यह एक **अलग से चलने वाली AI Chat API** है। यह अपने-आप Ola Party ऐप में बॉट लॉगिन/मैसेज नहीं भेजती। Ola Party से जोड़ने के लिए उनके आधिकारिक API, webhook या अधिकृत bot integration की जरूरत होगी।

## इसमें क्या है?
- `GET /` — जानकारी
- `GET /health` — health check
- `POST /chat` — API key से सुरक्षित chat endpoint
- `/docs` — browser में API test करने का पेज
- Render पर deploy करने के लिए `render.yaml`

## 1) Render पर मुफ्त deploy
1. https://github.com पर अकाउंट बनाकर इस ZIP को अपने कंप्यूटर पर extract करें।
2. सभी files को एक GitHub repository में upload करें।
3. https://render.com पर GitHub से sign in करें।
4. **New + → Blueprint** चुनें और repository connect करें।
5. Render `render.yaml` पढ़कर service बनाएगा। Free plan उपलब्धता/सीमाएँ बदल सकती हैं; free services idle होने पर sleep हो सकती हैं।
6. Render के Environment settings में `OPENAI_API_KEY` जोड़ें। यह optional है, लेकिन असली AI जवाबों के लिए provider API key चाहिए और उसका अलग खर्च हो सकता है। `BOT_API_KEY` Render खुद generate करेगा।
7. Deploy पूरा होने पर Render URL ऐसा होगा: `https://your-service-name.onrender.com`। यह केवल उदाहरण है, आपका वास्तविक URL Render देगा।

## 2) API test करना
अपने Render URL को `YOUR_RENDER_URL` से बदलें।

`GET https://YOUR_RENDER_URL/health`

Chat request:
```bash
curl -X POST "https://YOUR_RENDER_URL/chat" \
  -H "Content-Type: application/json" \
  -H "X-API-Key: YOUR_BOT_API_KEY" \
  -d '{"message":"Namaste, kaise ho?","user_id":"test-user"}'
```

Android पर चाहें तो Render URL के आखिर में `/docs` खोलकर Swagger UI से test कर सकते हैं। `X-API-Key` में Render Environment से अपना `BOT_API_KEY` डालें।

## सुरक्षा
- अपनी `BOT_API_KEY` या `OPENAI_API_KEY` किसी को न भेजें और code में hard-code न करें।
- अगर API key सार्वजनिक हो जाए, तो Render Environment में उसे बदलें और redeploy करें।
- OpenAI/provider API usage मुफ्त होने की गारंटी नहीं है; provider की current pricing और limits देखें।

## Ola Party से जोड़ना
पहले Ola Party के आधिकारिक support/developer channel से पूछें कि bot API/webhook उपलब्ध है या नहीं और कौन-सी अनुमति चाहिए। अगर supported webhook मिले, तो उसके documented event format के अनुसार adapter जोड़ना होगा। Unofficial automation, password sharing या app protections bypass करने की कोशिश न करें।
