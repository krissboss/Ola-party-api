import os
import secrets
from typing import Optional

from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from openai import OpenAI

app = FastAPI(
    title="Ola Party AI Bot API (Starter)",
    description="Standalone AI chat API. Ola Party integration requires an authorized official API/webhook.",
    version="1.0.0",
)

API_KEY = os.getenv("BOT_API_KEY", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=4000)
    user_id: Optional[str] = Field(default="guest", max_length=100)

class ChatResponse(BaseModel):
    reply: str
    mode: str

def check_key(provided: Optional[str]):
    # Set BOT_API_KEY in hosting environment before using publicly.
    if not API_KEY:
        raise HTTPException(status_code=503, detail="Server setup incomplete: BOT_API_KEY is not configured.")
    if not provided or not secrets.compare_digest(provided, API_KEY):
        raise HTTPException(status_code=401, detail="Invalid or missing X-API-Key header.")

@app.get("/")
def home():
    return {
        "name": "Ola Party AI Bot API starter",
        "status": "online",
        "health": "/health",
        "docs": "/docs",
        "chat_endpoint": "POST /chat",
        "note": "Standalone API; Ola Party connection requires an authorized official integration."
    }

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/chat", response_model=ChatResponse)
def chat(payload: ChatRequest, x_api_key: Optional[str] = Header(default=None)):
    check_key(x_api_key)

    if OPENAI_API_KEY:
        try:
            client = OpenAI(api_key=OPENAI_API_KEY)
            response = client.chat.completions.create(
                model=MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "You are a friendly chat-room assistant. Reply helpfully and briefly. "
                            "Use Hindi/Hinglish when the user writes in Hindi/Hinglish. "
                            "Do not claim to be an official Ola Party bot."
                        ),
                    },
                    {"role": "user", "content": payload.message},
                ],
                max_tokens=350,
            )
            reply = response.choices[0].message.content or "Maaf kijiye, abhi jawab nahi bana."
            return ChatResponse(reply=reply, mode="openai")
        except Exception:
            raise HTTPException(status_code=502, detail="AI provider request failed. Check OPENAI_API_KEY and provider limits.")

    return ChatResponse(
        reply=f"Namaste! Aapne kaha: {payload.message}. AI replies chalu karne ke liye hosting me OPENAI_API_KEY set karein.",
        mode="demo",
    )
