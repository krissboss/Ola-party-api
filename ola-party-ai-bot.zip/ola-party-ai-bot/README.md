# Ola Party AI Bot API

A simple starter API. This is **not connected to the official Ola Party app** and does not provide genuine AI responses yet.

## Run locally
1. Install Node.js.
2. In this folder run `npm install`.
3. Run `npm start`.
4. Open `http://localhost:3000`.

## Endpoints
- `GET /` — health check
- `POST /api/chat` — send a JSON body such as `{"message":"Hello"}`

Example with curl:
```bash
curl -X POST http://localhost:3000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Hello"}'
```

## Deploy on Render
1. Upload these files to a GitHub repository.
2. In Render, create a **New Web Service** and connect the repository.
3. Set Build Command to `npm install`.
4. Set Start Command to `npm start`.
5. Deploy. Your service URL will be shown by Render.

Keep any AI provider API keys private; never commit secrets to GitHub.
