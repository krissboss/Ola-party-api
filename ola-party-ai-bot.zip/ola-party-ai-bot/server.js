const express = require("express");

const app = express();
app.use(express.json());

app.get("/", (req, res) => {
  res.json({
    status: "online",
    bot: "Ola Party AI Bot",
    message: "API is running!"
  });
});

app.post("/api/chat", (req, res) => {
  const message = req.body?.message;

  if (typeof message !== "string" || !message.trim()) {
    return res.status(400).json({
      success: false,
      error: "Please send a non-empty message."
    });
  }

  res.json({
    success: true,
    bot: "Ola Party AI Bot",
    reply: `Aapne kaha: ${message.trim()}`
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Ola Party AI Bot API listening on port ${PORT}`);
});
